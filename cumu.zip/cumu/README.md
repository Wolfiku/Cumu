# Cumu – Self-Hosted Music Streaming

A lightweight, self-hosted music streaming web app built with PHP and SQLite.
Designed to run on a NAS or home server with Apache or Nginx.

---

## Requirements

- PHP 8.0 or higher
- Apache (with mod_rewrite + mod_headers) or Nginx
- PHP extensions: `pdo`, `pdo_sqlite`, `fileinfo`
- Write permission on the `database/` and `covers/` directories

---

## Quick Start

### 1. Deploy the files

Copy the `cumu/` directory to your web server's document root or a subdirectory.

```
/var/www/html/cumu/
```

### 2. Set permissions

```bash
chmod 750 database/
chmod 750 covers/
chmod 750 music/
```

### 3. Add music

Place your audio files inside the `music/` directory following this structure:

```
music/
└── Artist Name/
    └── Album Name/
        ├── 01 - Track Title.mp3
        ├── 02 - Another Track.mp3
        └── cover.jpg
```

### 4. Run the music scanner

**CLI (recommended):**
```bash
php scanner/scan_music.php
```

**Browser:**
Visit `http://your-nas/cumu/scanner/scan_music.php` while logged in.

### 5. Open Cumu

Navigate to `http://your-nas/cumu/` and create an account.

---

## Apache Configuration

The included `.htaccess` files handle most configuration automatically.

Make sure `AllowOverride All` is set in your Apache virtual host:

```apache
<Directory /var/www/html/cumu>
    AllowOverride All
    Require all granted
</Directory>
```

Enable required modules:
```bash
a2enmod rewrite headers
systemctl reload apache2
```

---

## Nginx Configuration

For Nginx, add these rules to your server block:

```nginx
server {
    listen 80;
    server_name cumu.local;
    root /var/www/html/cumu;
    index index.php;

    # Block direct access to sensitive directories
    location ~ ^/(music|database|backend)/ {
        deny all;
        return 403;
    }

    # Allow stream.php through
    location = /backend/stream.php {
        fastcgi_pass unix:/run/php/php8.2-fpm.sock;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/run/php/php8.2-fpm.sock;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }

    location / {
        try_files $uri $uri/ =404;
    }
}
```

---

## Optional: ID3 Metadata (getID3)

For accurate track metadata extraction, install getID3 via Composer:

```bash
cd /var/www/html/cumu
composer require james-heinrich/getid3
```

Without it, the scanner will infer artist/album from folder names and the
track title from the filename.

---

## Supported Audio Formats

| Format | MIME type         |
|--------|-------------------|
| MP3    | audio/mpeg        |
| FLAC   | audio/flac        |
| OGG    | audio/ogg         |
| WAV    | audio/wav         |
| M4A    | audio/mp4         |
| AAC    | audio/aac         |
| OPUS   | audio/ogg; codecs=opus |

---

## Security Notes

- Passwords are hashed with **bcrypt** (cost 12) via `password_hash()`.
- All database queries use **prepared statements** (no SQL injection risk).
- The `/music/` directory is blocked from direct HTTP access.
- The `/database/` directory is blocked from direct HTTP access.
- Sessions use `httponly` and `SameSite=Strict` cookies.
- Directory traversal is prevented in `stream.php` via `realpath()` validation.
- HTTP security headers are set via `.htaccess`.

---

## Project Structure

```
cumu/
├── index.php           Login page
├── register.php        Registration page
├── dashboard.php       Main dashboard with song list
├── library.php         Music library (artist/album view)
├── playlists.php       Playlist management
├── style.css           All styles
├── player.js           Frontend audio player
│
├── backend/
│   ├── session.php     DB init + session helpers
│   ├── layout.php      Shared HTML partials (sidebar, player bar)
│   ├── login.php       Login endpoint
│   ├── register.php    Registration endpoint
│   ├── logout.php      Logout endpoint
│   └── stream.php      Secure audio streaming (Range-request aware)
│
├── scanner/
│   └── scan_music.php  Music indexer
│
├── music/              Your audio files (not publicly accessible)
├── covers/             Cached album art
└── database/
    └── cumu.db         SQLite database (auto-created on first run)
```

---

## Roadmap

- [ ] Playlist editing (add/remove/reorder songs)
- [ ] Album art extraction from embedded ID3 tags
- [ ] User-specific settings (repeat, shuffle)
- [ ] Admin panel (user management, re-scan)
- [ ] Multi-user support with per-user libraries
- [ ] PWA / offline support
- [ ] FLAC and gapless playback improvements
